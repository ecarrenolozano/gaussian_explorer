# Approval Records

These records demonstrate the expected structure of meaningful approval gates. Replace names and dates during a real execution.

## APPR-001 — Project context approval

- **Artifact:** `01_project_context/project_context.md`
- **Reviewer role:** Project owner
- **Decision:** Approved
- **Required checks:** Purpose, users, constraints, non-goals, terminology
- **Downstream stage unlocked:** Requirements specification

## APPR-002 — Requirements approval

- **Artifacts:** `02_requirements/product_requirements.md`, `02_requirements/user_stories.md`
- **Reviewer roles:** Project owner and representative user
- **Decision:** Approved
- **Required checks:** Scope completeness, resolved ambiguities, testability, non-goals
- **Downstream stage unlocked:** Architecture design

## APPR-003 — Architecture approval

- **Artifacts:** `03_architecture/architecture_overview.md`, diagrams, ADRs
- **Reviewer role:** Technical reviewer
- **Decision:** Approved with ADR-004 still requiring framework confirmation during planning
- **Required checks:** Requirement coverage, dependency direction, proportionality, testability
- **Downstream stage unlocked:** Implementation planning

## APPR-004 — Implementation-plan approval

- **Artifact:** `04_implementation/implementation_plan.md`
- **Reviewer roles:** Developer and technical reviewer
- **Decision:** Approved
- **Required checks:** Increment ordering, requirement mapping, test strategy, completion criteria
- **Downstream stage unlocked:** Implementation

## APPR-005 — Validation approval

- **Artifact:** `06_validation/validation_report.md`
- **Reviewer roles:** Project owner and technical reviewer
- **Decision:** Pending actual implementation evidence
- **Required checks:** Acceptance evidence, deviations, defects, manual GUI results
- **Downstream stage unlocked:** Deployment approval

## APPR-006 — Deployment approval

- **Artifacts:** `07_deployment/deployment_plan.md`, `07_deployment/runbook.md`
- **Reviewer role:** Release approver
- **Decision:** Pending actual release evidence
- **Required checks:** Approved validation, passing checks, smoke test, rollback guidance
- **Downstream stage unlocked:** Release/use

## Revision behavior

When an approved upstream artifact changes materially:

- Record a new revision.
- Perform change-impact analysis.
- Mark affected downstream artifacts as stale.
- Repeat the necessary reviews and approvals.
- Do not silently preserve the previous approval status.
