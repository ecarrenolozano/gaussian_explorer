# Architecture Overview

## Architectural approach

The application uses a small layered architecture with dependency inversion around persistence.

```text
Web interface
    ↓
Presentation controller
    ↓
Application service
    ↓
Domain model
    ↓
Repository interface
    ↑
JSON repository adapter
    ↓
Local JSON file
```

## Rationale

This design provides enough structure to test architectural skills while remaining proportional to the problem. It supports:

- Testing business behavior without the GUI
- Replacing JSON persistence without changing domain behavior
- Clear module and class responsibilities
- Explicit dependency direction
- Component, class, sequence, and state modeling

The design intentionally avoids microservices, message brokers, event sourcing, distributed deployment, and dependency-injection frameworks.

## Runtime containers

| Container | Responsibility |
|---|---|
| Web browser | Display the GUI and collect user actions |
| Python web application | Execute presentation, application, and domain behavior |
| Local JSON file | Persist task records between restarts |

## Logical components

| Component | Responsibility |
|---|---|
| Web App | Render forms, board columns, messages, and controls |
| Board Controller | Translate GUI actions into application calls and view results |
| Task Service | Coordinate create, edit, move, delete, list, load, and save use cases |
| Task Validator | Normalize and validate task inputs |
| Domain Model | Represent tasks, statuses, and board behavior |
| Task Repository | Define persistence operations required by the application |
| JSON Task Repository | Read and write task data using JSON |
| Task Mapper | Convert between domain objects and JSON-compatible records |

## Dependency rules

- Presentation depends on the application layer.
- The application layer depends on the domain model and repository interface.
- The domain model does not depend on the GUI, web framework, JSON, or file system.
- The JSON adapter implements the repository interface.
- Persistence exceptions are translated into application-level failures before reaching the GUI.

## Proposed modules

```text
src/todo_board/
├── domain/
│   ├── task.py
│   ├── board.py
│   └── task_status.py
├── application/
│   ├── task_service.py
│   ├── task_validator.py
│   └── errors.py
├── ports/
│   └── task_repository.py
├── adapters/
│   ├── json_task_repository.py
│   └── task_mapper.py
├── presentation/
│   ├── board_controller.py
│   └── web_app.py
└── bootstrap.py
```

## Main classes

| Class | Main responsibility |
|---|---|
| `TaskStatus` | Define valid statuses |
| `Task` | Represent one task and enforce task-level invariants |
| `Board` | Manage the task collection |
| `TaskValidator` | Validate and normalize user-supplied values |
| `TaskRepository` | Define persistence contract |
| `JsonTaskRepository` | Implement JSON-based persistence |
| `TaskMapper` | Map domain objects to and from records |
| `TaskService` | Execute application use cases |
| `BoardController` | Coordinate presentation requests and responses |

## Failure behavior

- Invalid input produces a validation result without changing persisted state.
- Missing storage produces an empty board.
- Invalid storage stops normal loading and reports a clear error.
- Persistence failure is reported; the operation is not shown as successful.
- Unknown task identifiers produce a controlled not-found error.
