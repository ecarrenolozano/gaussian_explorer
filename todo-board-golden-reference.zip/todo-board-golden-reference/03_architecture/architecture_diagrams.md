# Architecture Diagrams

The diagrams use PlantUML source so they can be copied into `.puml` files later.

## System context

```plantuml
@startuml
title Todo Board - System Context
actor User
rectangle "Todo Board\nSoftware System" as TodoBoard
database "Local File System" as FileSystem
User --> TodoBoard : Creates, edits, moves,\nfilters, and deletes tasks
TodoBoard --> FileSystem : Reads and writes\nlocal task data
@enduml
```

## Container diagram

```plantuml
@startuml
title Todo Board - Containers
actor User
rectangle "Web Browser\n[Browser]" as Browser
rectangle "Todo Board Application\n[Python Web Application]" as App
database "tasks.json\n[Local JSON File]" as JsonFile
User --> Browser : Uses
Browser --> App : Sends actions and\ndisplays board
App --> JsonFile : Reads and writes tasks
@enduml
```

## Component diagram

```plantuml
@startuml
title Todo Board - Components
package "Presentation" {
  [Web App]
  [Board Controller]
}
package "Application" {
  [Task Service]
  [Task Validator]
}
package "Domain" {
  [Task]
  [Task Status]
  [Board]
}
package "Ports" {
  interface "Task Repository" as Repository
}
package "Adapters" {
  [JSON Task Repository]
  [Task Mapper]
}
database "tasks.json" as Storage
[Web App] --> [Board Controller]
[Board Controller] --> [Task Service]
[Task Service] --> [Task Validator]
[Task Service] --> [Task]
[Task Service] --> [Board]
[Task Service] --> Repository
[JSON Task Repository] ..|> Repository
[JSON Task Repository] --> [Task Mapper]
[Task Mapper] --> [Task]
[JSON Task Repository] --> Storage
@enduml
```

## Class diagram

```plantuml
@startuml
title Todo Board - Class Diagram
enum TaskStatus {
  TODO
  IN_PROGRESS
  DONE
}
class Task {
  - id: UUID
  - title: str
  - description: str?
  - status: TaskStatus
  + rename(title: str): void
  + update_description(description: str?): void
  + move_to(status: TaskStatus): void
}
class Board {
  - tasks: list<Task>
  + add(task: Task): void
  + remove(task_id: UUID): void
  + find(task_id: UUID): Task
  + list_all(): list<Task>
  + filter_by_status(status: TaskStatus): list<Task>
}
class TaskValidator {
  + validate_title(title: str): str
  + validate_status(status: TaskStatus): TaskStatus
}
interface TaskRepository {
  + load_all(): list<Task>
  + save_all(tasks: list<Task>): void
}
class JsonTaskRepository {
  - file_path: Path
  - mapper: TaskMapper
  + load_all(): list<Task>
  + save_all(tasks: list<Task>): void
}
class TaskMapper {
  + to_record(task: Task): dict
  + from_record(record: dict): Task
}
class TaskService {
  - board: Board
  - repository: TaskRepository
  - validator: TaskValidator
  + create_task(title: str, description: str?): Task
  + edit_task(task_id: UUID, title: str, description: str?): Task
  + move_task(task_id: UUID, status: TaskStatus): Task
  + delete_task(task_id: UUID): void
  + list_tasks(status: TaskStatus?): list<Task>
}
class BoardController {
  - service: TaskService
  + create_task(form_data): ViewResult
  + edit_task(task_id: UUID, form_data): ViewResult
  + move_task(task_id: UUID, status: str): ViewResult
  + delete_task(task_id: UUID, confirmed: bool): ViewResult
  + list_tasks(filter: str?): ViewModel
}
Task --> TaskStatus
Board "1" o-- "0..*" Task
TaskService --> Board
TaskService --> TaskValidator
TaskService --> TaskRepository
JsonTaskRepository ..|> TaskRepository
JsonTaskRepository --> TaskMapper
TaskMapper --> Task
BoardController --> TaskService
@enduml
```

## Task state machine

```plantuml
@startuml
title Todo Board - Task Status State Machine
[*] --> ToDo : task created
ToDo --> InProgress : move
ToDo --> Done : move
InProgress --> ToDo : move
InProgress --> Done : move
Done --> ToDo : move
Done --> InProgress : move
ToDo --> [*] : delete confirmed
InProgress --> [*] : delete confirmed
Done --> [*] : delete confirmed
@enduml
```

## Create-task sequence

```plantuml
@startuml
title Todo Board - Create Task Sequence
actor User
boundary WebApp
control BoardController
control TaskService
control TaskValidator
entity Board
interface TaskRepository
User -> WebApp : Enter title and description
WebApp -> BoardController : create_task(form_data)
BoardController -> TaskService : create_task(title, description)
TaskService -> TaskValidator : validate_title(title)
alt invalid title
  TaskValidator --> TaskService : validation error
  TaskService --> BoardController : failure
  BoardController --> WebApp : display validation message
else valid title
  TaskValidator --> TaskService : normalized title
  TaskService -> Board : add(new Task)
  TaskService -> TaskRepository : save_all(tasks)
  alt persistence succeeds
    TaskRepository --> TaskService : success
    TaskService --> BoardController : created task
    BoardController --> WebApp : refresh board
  else persistence fails
    TaskRepository --> TaskService : persistence error
    TaskService --> BoardController : failure
    BoardController --> WebApp : display storage error
  end
end
@enduml
```
