# Architecture Decision Records

## ADR-001 — Use a modular monolith

**Status:** Accepted

### Context

The project needs several meaningful modules and classes, but its runtime and business logic are small.

### Decision

Implement the application as one Python process organized into presentation, application, domain, ports, and adapters modules.

### Consequences

- Architectural relationships remain visible and testable.
- Deployment stays simple.
- The project avoids artificial distributed-system complexity.

---

## ADR-002 — Use a repository interface for persistence

**Status:** Accepted

### Context

The workflow must demonstrate dependency direction, interfaces, implementations, and integration testing.

### Decision

Define a `TaskRepository` interface in the ports layer. The application service depends on this interface, while `JsonTaskRepository` implements it.

### Consequences

- Business behavior can be tested with an in-memory repository.
- JSON storage can be replaced later without changing application use cases.
- One additional abstraction is introduced, but it has a clear consumer.

---

## ADR-003 — Use local JSON persistence

**Status:** Accepted

### Context

The application must restore tasks after restart, but does not need concurrent access, complex queries, or production-scale durability.

### Decision

Persist the complete task collection in a local JSON file.

### Consequences

- Storage is easy to inspect and reset.
- Integration tests are straightforward.
- Concurrent writes and large datasets are not supported.

---

## ADR-004 — Use a Python web GUI framework

**Status:** Proposed; select during implementation planning

### Context

The application requires a small web GUI and should remain accessible to Python developers.

### Decision

Use a lightweight Python framework such as Streamlit for the baseline unless the implementation skill identifies a concrete incompatibility with the approved requirements.

### Consequences

- The GUI can be implemented quickly.
- Browser interaction and Python application execution may be tightly coupled.
- Framework-specific behavior must remain outside the domain layer.
