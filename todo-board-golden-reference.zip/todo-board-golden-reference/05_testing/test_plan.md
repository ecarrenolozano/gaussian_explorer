# Test Plan

## Purpose

Demonstrate that tests are derived from requirements and architecture, and that different test levels have distinct purposes.

## Unit tests

Verify isolated domain and application behavior.

| Test ID | Target | Main behavior |
|---|---|---|
| TEST-U-001 | `TaskValidator` | Accept valid title and normalize surrounding whitespace |
| TEST-U-002 | `TaskValidator` | Reject empty title |
| TEST-U-003 | `TaskValidator` | Reject whitespace-only title |
| TEST-U-004 | `Task` | Assign `To Do` at creation |
| TEST-U-005 | `Task` | Move to each valid status |
| TEST-U-006 | `Board` | Add, find, filter, and remove tasks |
| TEST-U-007 | `TaskService` | Create and persist a task |
| TEST-U-008 | `TaskService` | Reject invalid edit without changing existing task |
| TEST-U-009 | `TaskService` | Move and persist a task |
| TEST-U-010 | `TaskService` | Delete only after controller-level confirmation |
| TEST-U-011 | `TaskService` | Report repository failure as application failure |

## Integration tests

Verify the JSON adapter and file-system interaction.

| Test ID | Behavior |
|---|---|
| TEST-I-001 | Save tasks and load equivalent tasks |
| TEST-I-002 | Missing file returns an empty collection |
| TEST-I-003 | Invalid JSON produces a controlled error |
| TEST-I-004 | Structurally invalid records produce a controlled error |
| TEST-I-005 | Failed read does not overwrite the source file |
| TEST-I-006 | Safe write replaces the target only after successful serialization |

## Acceptance tests

Verify complete user-visible behavior through the application boundary.

| Test ID | Acceptance criteria |
|---|---|
| TEST-A-001 | AC-001 to AC-004 |
| TEST-A-002 | AC-005 to AC-007 |
| TEST-A-003 | AC-008 to AC-011 |
| TEST-A-004 | AC-012 to AC-014 |
| TEST-A-005 | AC-015 and AC-016 |
| TEST-A-006 | AC-017 to AC-019 |

## UI smoke tests

- Application starts without an existing storage file.
- The board displays the three statuses.
- Task creation controls are visible.
- A validation or storage error can be rendered.

## Manual usability checks

A human reviewer verifies that:

- Creating a task is understandable without technical documentation.
- Moving a task requires no more than a simple visible action.
- Deletion confirmation is unambiguous.
- Errors do not appear as successful operations.
- The board remains readable with several tasks in each column.

## Exit criteria

- All mandatory automated tests pass.
- Every acceptance criterion has evidence.
- No unresolved critical or high-severity defect remains.
- The technical reviewer approves test sufficiency.
- The project owner approves user-visible behavior.
