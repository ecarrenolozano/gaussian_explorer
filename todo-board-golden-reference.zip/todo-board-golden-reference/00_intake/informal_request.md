# Informal Project Request

## Source

Requester message

## Original request

I need a small web application for managing personal tasks.

Users should be able to create tasks and organize them into three columns:

- To Do
- In Progress
- Done

Users should also be able to edit or delete tasks.

The application should be simple to run locally and should remember the tasks after it is restarted.

## Notes

This message is intentionally incomplete. It should be treated as raw input to requirements clarification rather than as a complete specification.
