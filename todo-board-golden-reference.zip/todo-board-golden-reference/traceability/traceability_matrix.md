# Traceability Matrix

## Requirement-to-evidence traceability

| Requirement | User story | Acceptance criteria | Architecture elements | Planned tests | Validation evidence |
|---|---|---|---|---|---|
| REQ-TASK-001 | US-001 | AC-001 | Task, Board, TaskService, BoardController | TEST-U-007, TEST-A-001 | AC-001 result |
| REQ-TASK-002 | US-001, US-002 | AC-002, AC-003, AC-007 | TaskValidator, TaskService | TEST-U-001 to TEST-U-003, TEST-U-008 | AC-002, AC-003, AC-007 results |
| REQ-TASK-003 | US-001 | AC-001 | Task, TaskStatus | TEST-U-004, TEST-A-001 | AC-001 result |
| REQ-TASK-004 | US-002 | AC-005 to AC-007 | Task, TaskService, BoardController | TEST-U-008, TEST-A-002 | AC-005 to AC-007 results |
| REQ-TASK-005 | US-003 | AC-008 to AC-011 | TaskStatus, Task, TaskService | TEST-U-005, TEST-U-009, TEST-A-003 | AC-008 to AC-011 results |
| REQ-TASK-006 | US-004 | AC-012 to AC-014 | BoardController, TaskService, Board | TEST-U-010, TEST-A-004 | AC-012 to AC-014 results |
| REQ-TASK-007 | US-003 | AC-008, AC-009 | Board, Web App | TEST-A-003, UI smoke | AC-008, AC-009 results |
| REQ-TASK-008 | US-005 | AC-015, AC-016 | Board, TaskService, BoardController | TEST-A-005 | AC-015, AC-016 results |
| REQ-DATA-001 | US-001 to US-004 | AC-004, AC-005, AC-006, AC-010, AC-014 | TaskRepository, JsonTaskRepository | TEST-U-007, TEST-U-009, TEST-I-001 | Persistence evidence |
| REQ-DATA-002 | US-006 | AC-017 | JsonTaskRepository, TaskMapper | TEST-I-001, TEST-A-006 | AC-017 result |
| REQ-DATA-003 | US-006 | AC-018 | JsonTaskRepository | TEST-I-002, TEST-A-006 | AC-018 result |
| REQ-DATA-004 | US-006 | AC-019 | JsonTaskRepository, application errors, Web App | TEST-I-003 to TEST-I-005, TEST-A-006 | AC-019 result |
| QR-MAINTAINABILITY-001 | — | — | All layers and dependency rules | Architecture review | Reviewer conclusion |
| QR-TESTABILITY-001 | — | — | Domain, application, repository port | Headless unit suite | Test execution evidence |
| QR-RELIABILITY-001 | — | — | Repository adapter and error translation | TEST-U-011, TEST-I-003 to TEST-I-006 | Failure-behavior evidence |
| QR-DOCUMENTATION-001 | — | — | README, deployment plan, runbook | Documentation walkthrough | Reviewer conclusion |

## Example end-to-end chain

```text
Informal request
  → CQ-001 and CQ-002
  → REQ-TASK-001 and REQ-TASK-002
  → US-001
  → AC-001, AC-002, AC-003, AC-004
  → TaskValidator, TaskService, TaskRepository
  → TEST-U-001, TEST-U-002, TEST-U-003, TEST-U-007, TEST-A-001
  → Validation results for AC-001 through AC-004
  → APPR-005 validation approval
```
