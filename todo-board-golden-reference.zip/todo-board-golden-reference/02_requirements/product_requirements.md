# Product Requirements

## Functional requirements

### REQ-TASK-001 — Create a task

The user shall be able to create a task with a mandatory title and an optional description.

### REQ-TASK-002 — Validate task title

The application shall reject a task title that is empty or contains only whitespace.

### REQ-TASK-003 — Assign initial status

A newly created task shall have the status `To Do`.

### REQ-TASK-004 — Edit a task

The user shall be able to edit the title and description of an existing task.

### REQ-TASK-005 — Move a task

The user shall be able to move a task directly between `To Do`, `In Progress`, and `Done`.

### REQ-TASK-006 — Delete a task

The user shall be able to delete a task after confirming the action.

### REQ-TASK-007 — Display tasks by status

The application shall display tasks grouped according to their status.

### REQ-TASK-008 — Filter tasks

The user shall be able to show all tasks or only tasks in one selected status.

### REQ-DATA-001 — Persist successful changes

The application shall save task data after a successful create, edit, move, or delete operation.

### REQ-DATA-002 — Restore tasks

The application shall restore saved tasks when it starts.

### REQ-DATA-003 — Handle missing storage

If the storage file does not exist, the application shall start with an empty board.

### REQ-DATA-004 — Handle invalid storage

If stored data cannot be read or validated, the application shall report the problem and shall not silently overwrite the invalid data.

## Quality requirements

### QR-USABILITY-001 — Basic usability

A user shall be able to create and move a task without reading technical documentation.

### QR-MAINTAINABILITY-001 — Separation of concerns

Domain behavior, application orchestration, persistence, and presentation shall be implemented in separate modules.

### QR-TESTABILITY-001 — Headless business testing

Business behavior shall be testable without starting the web interface.

### QR-PORTABILITY-001 — Local portability

The application shall run on supported Python environments on Linux, macOS, and Windows where its dependencies are available.

### QR-RELIABILITY-001 — Persistence failure reporting

A failed persistence operation shall be reported and shall not be represented to the user as a successful change.

### QR-DOCUMENTATION-001 — Operational documentation

The repository shall contain installation, execution, testing, storage-reset, and troubleshooting instructions.

## Requirement priorities

All functional requirements and quality requirements listed above are mandatory for the golden baseline.
