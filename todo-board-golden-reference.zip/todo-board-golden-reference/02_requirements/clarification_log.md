# Requirements Clarification Log

## Purpose

This log records ambiguities found in the informal request and the decisions used to resolve them.

| ID | Question | Decision | Decision owner |
|---|---|---|---|
| CQ-001 | Is a task title mandatory? | Yes | Project owner |
| CQ-002 | Can a title contain only whitespace? | No | Project owner |
| CQ-003 | Are duplicate task titles allowed? | Yes | Project owner |
| CQ-004 | Is a task description mandatory? | No | Project owner |
| CQ-005 | What is the initial status of a new task? | `To Do` | Project owner |
| CQ-006 | Can a task move directly between any two statuses? | Yes | Project owner |
| CQ-007 | Does deletion require confirmation? | Yes | Project owner |
| CQ-008 | Must task order be preserved? | No ordering requirement in the baseline | Project owner |
| CQ-009 | What does local persistence mean? | Tasks are restored after restarting the application | Project owner |
| CQ-010 | Which storage mechanism is acceptable? | A local JSON file is sufficient | Technical reviewer |
| CQ-011 | Is filtering required? | Yes, by status and `All` | Project owner |
| CQ-012 | Is drag-and-drop required? | No; buttons or selection controls are acceptable | Project owner |
| CQ-013 | What happens when the storage file is absent? | Start with an empty board | Project owner |
| CQ-014 | What happens when persisted data are invalid? | Report an error and do not overwrite the invalid file | Project owner and technical reviewer |
| CQ-015 | Which browsers are supported? | Current Firefox and Chromium-based browsers | Project owner |
| CQ-016 | What does simple to run mean? | Documented dependency installation and one documented start command | Project owner |

## Confirmed assumptions

- Only one process writes to the storage file at a time.
- The user controls the local computer and storage location.
- The project is a reference application, not a production service.
- Local file backup and encryption are outside baseline scope.

## Open questions

None block the baseline implementation.
