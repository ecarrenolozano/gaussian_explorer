# User Stories and Acceptance Criteria

## US-001 — Create a task

As a user, I want to create a task so that I can record work I need to do.

- **AC-001:** Given the application is open, when the user creates a task with a valid title, then the task appears in `To Do`.
- **AC-002:** Given the application is open, when the user submits an empty title, then no task is created and a validation message is shown.
- **AC-003:** Given the application is open, when the user submits a whitespace-only title, then no task is created.
- **AC-004:** Given a valid task is created, when the application restarts, then the task is restored.

## US-002 — Edit a task

As a user, I want to edit a task so that I can correct or update its content.

- **AC-005:** Given a task exists, when the user changes its title to another valid title, then the updated title is displayed and persisted.
- **AC-006:** Given a task exists, when the user changes its description, then the updated description is displayed and persisted.
- **AC-007:** Given a task exists, when the user replaces its title with an invalid value, then the change is rejected and the previous title remains.

## US-003 — Move a task

As a user, I want to move a task between columns so that its status reflects its progress.

- **AC-008:** Given a task is in `To Do`, when it is moved to `In Progress`, then it appears in `In Progress`.
- **AC-009:** Given a task is in `In Progress`, when it is moved to `Done`, then it appears in `Done`.
- **AC-010:** Given a task exists, when it is moved to any valid status, then the new status is persisted.
- **AC-011:** Given a task exists, when an invalid status reaches the application layer, then the change is rejected.

## US-004 — Delete a task

As a user, I want to delete a task so that obsolete work no longer appears.

- **AC-012:** Given a task exists, when deletion is requested, then the application asks for confirmation.
- **AC-013:** Given deletion confirmation is shown, when the user cancels, then the task remains unchanged.
- **AC-014:** Given deletion confirmation is shown, when the user confirms, then the task is removed and the deletion is persisted.

## US-005 — Filter tasks

As a user, I want to filter tasks by status so that I can focus on part of the board.

- **AC-015:** Given tasks exist in multiple states, when `All` is selected, then all tasks are shown.
- **AC-016:** Given tasks exist in multiple states, when one status is selected, then only tasks with that status are shown.

## US-006 — Restore saved tasks

As a user, I want saved tasks restored after restarting so that I do not lose my work.

- **AC-017:** Given valid tasks were saved, when the application restarts, then their identifiers, titles, descriptions, and statuses are restored.
- **AC-018:** Given no storage file exists, when the application starts, then an empty board is shown.
- **AC-019:** Given the storage file contains invalid data, when the application starts, then the problem is reported and the invalid file is not overwritten.
