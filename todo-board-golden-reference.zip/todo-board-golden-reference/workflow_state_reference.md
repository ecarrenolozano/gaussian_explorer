# Workflow State Reference

This is a human-readable example of information a workflow-state file may track.

```yaml
project: todo-board
workflow_version: 1
current_stage: validation
rigor_level: standard

artifacts:
  project_context:
    path: 01_project_context/project_context.md
    revision: 1.0
    status: approved
    approval: APPR-001
  requirements:
    paths:
      - 02_requirements/product_requirements.md
      - 02_requirements/user_stories.md
    revision: 1.0
    status: approved
    approval: APPR-002
  architecture:
    paths:
      - 03_architecture/architecture_overview.md
      - 03_architecture/architecture_diagrams.md
      - 03_architecture/architecture_decisions.md
    revision: 1.0
    status: approved
    approval: APPR-003
  implementation_plan:
    path: 04_implementation/implementation_plan.md
    revision: 1.0
    status: approved
    approval: APPR-004
  validation:
    path: 06_validation/validation_report.md
    revision: 0.1
    status: draft

next_eligible_actions:
  - complete implementation
  - execute tests
  - populate validation evidence

blocked_actions:
  - deployment_approval

stale_artifacts: []
open_questions: []
```

## Recommended states

- `draft`
- `validation_failed`
- `ready_for_review`
- `changes_requested`
- `approved`
- `rejected`
- `stale`
- `superseded`
- `archived`
