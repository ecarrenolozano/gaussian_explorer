# Local Runbook

## Install

Use the package manager selected by the implementation. The final project should provide exact commands, for example:

```bash
uv sync
```

or:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

## Run tests

```bash
pytest
```

## Start application

The final implementation should provide one authoritative command, for example:

```bash
streamlit run src/todo_board/presentation/web_app.py
```

## Storage

- Default file: `data/tasks.json`
- The directory must be writable.
- Back up the file before manually editing it or upgrading a format.

## Reset local data

1. Stop the application.
2. Back up `tasks.json` if needed.
3. Remove or rename the file.
4. Restart the application; an empty board should appear.

## Troubleshooting

### Application does not start

- Confirm the supported Python version.
- Reinstall dependencies from the approved lock or constraints.
- Review the complete startup error.

### Tasks do not persist

- Confirm the storage directory is writable.
- Confirm the application reports the intended storage path.
- Inspect logs for a persistence error.

### Invalid storage error

- Do not delete or overwrite the file automatically.
- Copy the invalid file for diagnosis.
- Restore a known-good backup or intentionally reset the data.
