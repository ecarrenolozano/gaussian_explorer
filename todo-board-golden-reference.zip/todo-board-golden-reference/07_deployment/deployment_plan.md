# Deployment Plan

## Deployment target

A local desktop or workstation running the Python web application and opening it in a supported browser.

## Deployment unit

The baseline deployment consists of:

- Python package source
- Locked or constrained dependencies
- Start command
- Local storage directory containing `tasks.json`
- Documentation and tests

A container may be provided as an optional reproducibility mechanism, but is not required for the baseline.

## Preconditions

- Supported Python version installed
- Dependency installer available
- Write permission for the configured storage directory
- Supported browser available

## Deployment steps

1. Obtain the approved release revision.
2. Create or activate an isolated Python environment.
3. Install the project dependencies.
4. Run automated tests.
5. Start the web application using the documented command.
6. Open the displayed local URL.
7. Complete the smoke check.

## Smoke check

- Application starts.
- Three columns are visible.
- A task can be created.
- The task remains after restart.
- The storage path is displayed or documented.

## Rollback

- Stop the application.
- Restore the previous approved project revision and dependency lock.
- Preserve or restore a backup of `tasks.json` when data format changes.
- Restart and repeat the smoke check.

## Release approval evidence

- Approved validation report
- Passing automated checks
- Successful smoke check
- Reviewed installation and run instructions
- Documented known limitations
