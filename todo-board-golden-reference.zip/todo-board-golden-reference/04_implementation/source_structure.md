# Proposed Source Structure

```text
src/
└── todo_board/
    ├── __init__.py
    ├── bootstrap.py
    ├── domain/
    │   ├── __init__.py
    │   ├── board.py
    │   ├── errors.py
    │   ├── task.py
    │   └── task_status.py
    ├── application/
    │   ├── __init__.py
    │   ├── errors.py
    │   ├── task_service.py
    │   └── task_validator.py
    ├── ports/
    │   ├── __init__.py
    │   └── task_repository.py
    ├── adapters/
    │   ├── __init__.py
    │   ├── json_task_repository.py
    │   └── task_mapper.py
    └── presentation/
        ├── __init__.py
        ├── board_controller.py
        ├── view_models.py
        └── web_app.py

tests/
├── unit/
│   ├── test_board.py
│   ├── test_task.py
│   ├── test_task_service.py
│   └── test_task_validator.py
├── integration/
│   └── test_json_task_repository.py
├── acceptance/
│   └── test_todo_board_workflows.py
└── smoke/
    └── test_application_startup.py
```

## Dependency guidance

- `domain` imports only the Python standard library and other domain modules.
- `application` imports domain modules and port interfaces.
- `ports` may import domain types used in contracts.
- `adapters` import ports and domain mapping types.
- `presentation` imports application-facing APIs, not adapter internals.
- `bootstrap.py` creates concrete objects and connects dependencies.
