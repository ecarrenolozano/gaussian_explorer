# Implementation Plan

## Objective

Implement the approved Todo Board baseline while preserving the architecture boundaries and requirement traceability.

## Increment 1 — Project foundation

### Deliverables

- Python project metadata
- Package and test directory structure
- Quality tooling configuration
- Minimal application bootstrap

### Completion criteria

- Package imports successfully.
- Test runner executes.
- Formatting, linting, and type-check commands are documented.

## Increment 2 — Domain model

### Deliverables

- `TaskStatus`
- `Task`
- `Board`
- Domain errors

### Requirements covered

- REQ-TASK-002
- REQ-TASK-003
- REQ-TASK-005
- REQ-TASK-007
- REQ-TASK-008

### Completion criteria

- Domain tests pass without GUI or file-system access.
- Invalid statuses and missing tasks produce controlled errors.

## Increment 3 — Application services

### Deliverables

- `TaskValidator`
- `TaskRepository` interface
- `TaskService`
- In-memory repository test double

### Requirements covered

- REQ-TASK-001 through REQ-TASK-008
- QR-TESTABILITY-001

### Completion criteria

- Create, edit, move, delete, and filter use cases pass unit tests.
- Application services depend only on domain types and repository abstraction.

## Increment 4 — JSON persistence

### Deliverables

- `TaskMapper`
- `JsonTaskRepository`
- Safe file writing strategy
- Persistence error translation

### Requirements covered

- REQ-DATA-001 through REQ-DATA-004
- QR-RELIABILITY-001

### Completion criteria

- Save and reload integration tests pass.
- Missing-file and invalid-file behavior are verified.
- Invalid source data are not overwritten.

## Increment 5 — Web interface

### Deliverables

- `BoardController`
- Task form
- Three status columns
- Edit, move, delete, and filter controls
- Error and confirmation messages

### Requirements covered

- All user stories
- QR-USABILITY-001

### Completion criteria

- Manual walkthrough completes all baseline actions.
- GUI contains no persistence or domain-rule implementation.

## Increment 6 — Acceptance validation and packaging

### Deliverables

- Acceptance tests
- UI smoke test
- Validation report
- Installation and run instructions
- Local deployment package or container, if selected

### Completion criteria

- Every acceptance criterion has evidence.
- Required automated checks pass.
- Human reviewer approves the validation report and release instructions.

## Dependency order

```text
Foundation
  ↓
Domain model
  ↓
Application services
  ↓
JSON persistence
  ↓
Web interface
  ↓
Acceptance validation and deployment
```

The web interface and JSON adapter may be implemented in parallel after the application-service contract is approved.
