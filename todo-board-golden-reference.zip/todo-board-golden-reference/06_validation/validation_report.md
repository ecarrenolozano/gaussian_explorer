# Validation Report Reference

## Validation objective

Determine whether the implemented Todo Board satisfies the approved product requirements and acceptance criteria.

## Validation status

**Reference status:** Expected evidence model. Actual execution results must be inserted by the workflow run.

## Acceptance evidence matrix

| Acceptance criterion | Expected evidence | Expected result |
|---|---|---|
| AC-001 | Acceptance test creates a valid task | Pass |
| AC-002 | Acceptance or UI test submits empty title | Pass |
| AC-003 | Unit/acceptance test submits whitespace-only title | Pass |
| AC-004 | Integration workflow restarts and reloads task | Pass |
| AC-005 | Acceptance test edits valid title | Pass |
| AC-006 | Acceptance test edits description | Pass |
| AC-007 | Unit/acceptance test rejects invalid edit and preserves old value | Pass |
| AC-008 | Acceptance test moves task to `In Progress` | Pass |
| AC-009 | Acceptance test moves task to `Done` | Pass |
| AC-010 | Restart/reload verifies moved status | Pass |
| AC-011 | Application test rejects invalid status | Pass |
| AC-012 | Manual or UI test verifies confirmation prompt | Pass |
| AC-013 | UI test/manual check cancels deletion | Pass |
| AC-014 | Acceptance test confirms deletion and persistence | Pass |
| AC-015 | Acceptance test selects `All` | Pass |
| AC-016 | Acceptance test filters by each status | Pass |
| AC-017 | Integration test restores identifiers and fields | Pass |
| AC-018 | Integration/startup test handles missing file | Pass |
| AC-019 | Integration/manual check reports invalid file without overwrite | Pass |

## Quality requirement evidence

| Requirement | Evidence |
|---|---|
| QR-USABILITY-001 | Human walkthrough and usability checklist |
| QR-MAINTAINABILITY-001 | Module dependency review and architecture comparison |
| QR-TESTABILITY-001 | Domain and service tests run without GUI |
| QR-PORTABILITY-001 | Documented supported Python/dependency matrix and representative platform runs |
| QR-RELIABILITY-001 | Persistence-failure tests and GUI error behavior |
| QR-DOCUMENTATION-001 | README/runbook review by a second developer |

## Human validation questions

- Does the delivered application match the approved baseline scope?
- Are errors understandable and distinguishable from success?
- Can a new user complete create, move, edit, filter, and delete actions?
- Is deployment documentation sufficient for another developer?
- Are any deviations from requirements documented and approved?

## Approval condition

The project owner may approve validation only after:

- All mandatory acceptance criteria pass.
- Manual GUI checks are completed.
- Deviations are resolved or explicitly accepted.
- Validation evidence is linked to concrete test results and versions.
