# Todo Board Golden Workflow Reference

## Purpose

This directory contains a canonical reference project for evaluating an agent-skill-based software development workflow. The Todo Board domain is deliberately simple, while the project structure is rich enough to exercise requirements, architecture, implementation planning, testing, validation, deployment, approval gates, and traceability.

Use this reference **after** running the workflow independently. Compare structure, completeness, consistency, assumptions, decisions, and traceability. Do not require generated artifacts to match the wording exactly.

## Baseline scope

The application allows one local user to:

- Create a task.
- Edit a task.
- Delete a task after confirmation.
- Move a task between `To Do`, `In Progress`, and `Done`.
- Filter tasks by status.
- Save and restore tasks locally.
- Use the application through a small web interface.

## Directory map

```text
00_intake/            Informal source request
01_project_context/   Purpose, stakeholders, constraints, terminology
02_requirements/      Clarifications, requirements, stories, acceptance criteria
03_architecture/      Architecture overview, decisions, and UML/C4-style models
04_implementation/    Implementation plan and proposed source organization
05_testing/           Test strategy and representative test catalogue
06_validation/        Requirement-by-requirement validation reference
07_deployment/        Deployment plan and local runbook
approvals/            Example human approval records
traceability/         Cross-lifecycle traceability matrix
```

## Suggested comparison criteria

Evaluate whether workflow-generated artifacts:

1. Preserve the original request without inventing facts.
2. Separate confirmed decisions, assumptions, open questions, and proposals.
3. Define testable requirements and acceptance criteria.
4. Maintain consistent identifiers across artifacts.
5. Justify architecture without adding unnecessary complexity.
6. Keep business rules outside the GUI and persistence implementation.
7. Distinguish automated checks from human approval.
8. Validate the product against acceptance criteria rather than test execution alone.
9. Provide enough deployment guidance for another developer to run the project.
10. Record approval evidence and revision history.

## Intended use as a golden example

The example is a semantic baseline, not a byte-for-byte output target. When a skill changes, rerun it against the same upstream inputs and compare:

- Missing or extra required sections
- Unsupported assumptions
- Traceability gaps
- Inconsistent terminology or identifiers
- Unjustified architecture decisions
- Weak validation evidence
- Missing approval behavior

Update this baseline only through an explicit human review and approval.
